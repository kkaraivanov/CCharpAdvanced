﻿namespace PizzaCalories.Common
{
    public enum Modifiers
    {
        White,
        Wholegrain,
        Crispy,
        Chewy,
        Homemade,
        Meat,
        Veggies,
        Cheese,
        Sauce
    }
}