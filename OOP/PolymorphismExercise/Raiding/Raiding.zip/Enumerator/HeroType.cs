﻿namespace Raiding.Enumerator
{
    public enum HeroType
    {
        Druid,
        Paladin,
        Rogue,
        Warrior
    }
}