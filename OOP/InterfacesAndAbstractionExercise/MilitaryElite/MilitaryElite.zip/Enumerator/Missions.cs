﻿namespace MilitaryElite.Enumerator
{
    public enum Missions
    {
        inprogress,
        finished
    }
}