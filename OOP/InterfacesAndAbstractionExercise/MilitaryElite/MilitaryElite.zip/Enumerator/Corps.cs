﻿namespace MilitaryElite.Enumerator
{
    public enum Corps
    {
        airforces,
        marines
    }
}