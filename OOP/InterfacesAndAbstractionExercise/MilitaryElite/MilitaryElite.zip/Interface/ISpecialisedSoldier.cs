﻿namespace MilitaryElite.Interface
{
    using Enumerator;

    public interface ISpecialisedSoldier
    {
        public string Corp { get;}
    }
}