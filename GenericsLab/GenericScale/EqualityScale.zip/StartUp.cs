﻿namespace GenericScale
{
    using System;
    using System.Drawing;

    public class StartUp
    {
        static void Main(string[] args)
        {
            
        }
    }
}
